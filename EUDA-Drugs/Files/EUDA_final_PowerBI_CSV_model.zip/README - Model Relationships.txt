EUDA SYNTHETIC POWER BI DEMONSTRATION MODEL

All values are synthetic and must not be presented as official EUDA statistics.

RELATIONSHIPS (single direction, one-to-many)
Calendar[Date] -> both fact tables[Reporting Month]
Countries[Country Code] -> both fact tables[Country Code]
Drugs[Drug Key] -> both fact tables[Drug Key]
Age Ranges[Age Range] -> Drug Health Monitoring[Age Range]
Genders[Gender] -> Drug Health Monitoring[Gender]

IMPORTANT GRAIN
Drug Health Monitoring: month x country x drug x age range x gender.
Drug Supply and Risk Monitoring: month x country x drug.
Do not join the two fact tables directly.
Do not analyse seizures, offences, new substance detections or risk by age/gender.

POWER BI DATA CATEGORIES
Countries[Country Code]: Country/Region
Countries[Latitude]: Latitude, Decimal Number, Do not summarize
Countries[Longitude]: Longitude, Decimal Number, Do not summarize
Calendar[Date] and both Reporting Month columns: Date

SORTING
Calendar[Month Name] sort by Calendar[Month Number].
Age Ranges[Age Range] sort by Age Ranges[Age Sort Order].
